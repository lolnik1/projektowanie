﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using BrickBreaker.Classes;
using System.Collections.Generic;

namespace Game4
{

    public class BrickBreaker : Game
    {
        SpriteFont font;
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        Ball ball;
        Paddle paddle;
        List<Brick> lstbricks;
        Texture2D pixel;

        int wynik = 0;
        int ballSize = 6;
        int paddleWidth = 40;
        int paddleHeight = 10;
        int brickHeight = 20;
        int brickWidth = 50;
        int brickRows = 6;

        int gameWidth = 500;
        int gameHeight = 600;

        public BrickBreaker()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";

            graphics.PreferredBackBufferWidth = gameWidth;
            graphics.PreferredBackBufferHeight = gameHeight;
        }

        protected override void Initialize()
        {


            base.Initialize();
        }


        protected override void LoadContent()
        {

            spriteBatch = new SpriteBatch(GraphicsDevice);
            ball = new Ball(this, GraphicsDevice, spriteBatch, ballSize);
            paddle = new Paddle(this, GraphicsDevice, spriteBatch, paddleWidth, paddleHeight);
            pixel = new Texture2D(GraphicsDevice, 1, 1);
            pixel.SetData(new Color[] { Color.White });
            lstbricks = new List<Brick>();
            font = Content.Load<SpriteFont>("font");

            Components.Add(paddle);
            Components.Add(ball);
            CreateBricks();
        }

        public void CreateBricks()
        {
            for(int i = 0; i < gameWidth / brickWidth; i++)
            {
                for(int j = 1; j < brickRows + 1; j++)
                {
                    lstbricks.Add(new Brick(this, GraphicsDevice, spriteBatch, brickWidth, brickHeight, i * brickWidth + i, j * brickHeight + j));
                }
            }

            foreach(var brick in lstbricks)
            {
                Components.Add(brick);
            }
        }


        protected override void UnloadContent()
        {

        }

        protected override void Update(GameTime gameTime)
        {
            if (ball.lives == 0)
            {
                Exit();
            }
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();
            else if(Keyboard.GetState().IsKeyDown(Keys.Space) && !ball.run)
            {
                ball.run = true;
            }

            paddle.PosX = Mouse.GetState().X;

            paddle.CheckPaddleBallCollision(ball);

            foreach(var item in lstbricks)
            {
                if (item.CheckBallColision(ball))
                {
                    item.active = false;
                    wynik += 10;
                }        
            }

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(new Color(51,51,51));

            spriteBatch.Begin();
            spriteBatch.Draw(pixel, new Rectangle(0, GraphicsDevice.Viewport.Height - 20, GraphicsDevice.Viewport.Width, 1), Color.White);
            spriteBatch.DrawString(font, "Points: " + wynik.ToString(), new Vector2(230, 300), new Color(70, 200, 50, 10));
            spriteBatch.DrawString(font, "Lives: " + ball.lives.ToString(), new Vector2(10, 585), new Color(70, 200, 50, 10));
            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
